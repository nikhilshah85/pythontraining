class Accounts:
    def __init__(self,accNo,name, lastname, acctype,balance) -> None:
        self.accountNumber = accNo;
        self.accountName = name;
        self.accountLastName = lastname;
        self.accountType = acctype;
        self.accountBalance = balance;

    def showBalance(self):
        print(self.accountBalance);


    def Widraw(self,w_amount):
        self.accountBalance = self.accountBalance - w_amount;
        return self.accountBalance;

    def Deposit(self,d_amount):
        self.accountBalance = self.accountBalance + d_amount;
        return self.accountBalance;

    def DisplayInfo(self):
        print("Account Number " + str(self.accountNumber));
        print("Account Name " + str(self.accountName) + str(self.accountLastName));
        print("Account Balance " + str(self.accountBalance));
        print("Account Type " + str(self.accountType));
        
        


class Savings(Accounts):                 
        def whoAmI(self):
        print("I am a Savings Account");
    
    def Widraw(self,amount):
        if amount > 5000:
            # raise an exception
            # raise Exception("You cannot widraw more than 5000");
            print("You cannot widraw more than 5000");
        else:
           self.accountBalance = self.accountBalance - amount;
           print("Widraw Successfull" + str(self.accountBalance) + " is the balance after Widrawal");  
            
            
        
        
class Current(Accounts):
    def whoAmI(self):
        print("I am a Current Account");
        
    def Widraw(self,amount):
        if amount > 10000:
            print("You cannot widraw more than 10000");
        else:
            self.accountBalance = self.accountBalance - amount;
            print("Widraw Successfull" + str(self.accountBalance) + " is the balance after Widrawal");  
      

class PF(Accounts):
    def whoAmI(self):
        print("I am a PF Accounts");
        
    def Widraw(self,amount):
        if amount > (self.accountBalance * 0.6):
            print("You cannot widraw more than " + str((self.accountBalance * 0.6)));
        else:
            self.accountBalance = self.accountBalance - amount;
            print("Widraw Successfull" + str(self.accountBalance) + " is the balance after Widrawal");  
      
        

savObj = Savings(101,"Nikhil","Shah","Savings",6000);
currObj = Current(102,"Rohit","Kumar","Current",23000);
pfObj = PF(103,"a","Sharma","PF",100000);

pfObj.Widraw(-35000);











        