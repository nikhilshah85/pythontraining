
def calculateNumbers(num1,num2,operator):
    
    if(num1 < num2):
        raise Exception("First Number needs to be bigger than 2nd");
    elif num2 < 0:
        raise Exception("Please pass only positive value");
    else:
          if operator == "Add":
            print(num1 + num2);
          elif operator == "Sub":
            print(num1 - num2);
          elif operator == "Div":
            print(num1 / num2);
          elif operator == "Mul":
            print(num1 * num2);
          else:
            raise Exception("Sorry Wrong Operator");



try:
    calculateNumbers(10,-2,"Add");
except Exception as err:
    print(err);
finally:
    print("Thank you for banking with us");


        
        