class Employee:
    def __init__(self,empName,empAge):
        if len(empName) < 3:
            print("Please provide a valid Name");   
        elif(empAge < 18):     
            print("Age should be minimum 18");
        elif(empAge > 60):
            print("Age is not valid, must be less than 60");
        else:
            self.employeeName = empName;
            self.employeeAge = empAge;    

class Developer(Employee):
    def __init__(self,eName,eAge,eCity):super(eName,eAge)
        print("Developer Created, welcome from ", eCity);
        
        
class Manager(Employee):
    def __init__(self,eName,eAge):super(eName,eAge):
        print("Manager Created");
        
        

dev = Developer("nik",30,"Mumbai");

