import Accounts

class Savings(Accounts):
    def moduleTest(self):
        print("Its working");
        

savObj2 = Savings();


