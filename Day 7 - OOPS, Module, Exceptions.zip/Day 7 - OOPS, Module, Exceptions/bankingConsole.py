import Accounts;

acc = Accounts(101,"Nikhil","Shah","Savings",6000);

savObj = Savings(101,"Nikhil","Shah","Savings",6000);
currObj = Current(102,"Rohit","Kumar","Current",23000);
pfObj = PF(103,"Sunil","Sharma","PF",100000);

# pfObj.Widraw(55000);

acc.DisplayInfo();
