favNumber =int(input('Enter Your Fav Number'));

if favNumber < 10:
    print('Poor Number');
elif favNumber > 10 and favNumber < 20:
    print('Average number');
elif favNumber > 20 and favNumber <30:
    print('Good Number');
elif favNumber >= 30:
    print('Excellent Number');
else:
    print('Number not in rateing categoty');


print('10 is greater than 20 ??') if 10 < 20 else print('No this is false');

age = int(input("Enter the Age in numeric"));

if age > 10:
    print('Stage 1');
    if age > 20:
        print('Stage 2');
        if age > 30:
            print('Stage 3');
            print('Keep Playing');
        else:
            print('Game Over');
    else:
        print('Game Over');
else:
    print('Not Eligable to Play the game')

    
    
    