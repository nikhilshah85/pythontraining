print('Hello World');
print('My name is Nikhil');
print('This is the first program, we wish to make more better programms');