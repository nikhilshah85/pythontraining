from xml.etree.ElementTree import tostring


name = "Nikhil";
lastName = "Shah";
designation = "Consultant";
print(name + " " + lastName + " is an " + designation);

num1 = 20;
num2 = 40;
addition = num1 + num2;
# print('Addition of my Numbers are : ', addition);
print('First Number : {}, second Number {} - Adds to {}'.format(num1,num2,addition));