num1 = input('Enter Your First Fav Number : ');
num2 = input('Enter Your Second Fav Number : ');

if int(num2) <= 0:
    print('Please enter number greater than 1');
else:  
    addResult = int(num1) + int(num2);
    subResult = int(num1) - int(num2);
    mulResult = int(num1) * int(num2);
    divResult = int(num1) / int(num2);  
    print("Addition : ",addResult );
    print("Subtraction : ",subResult );
    print("Division : ",divResult );
    print("Multiplication : ",mulResult);