# num = int(input("Enter A Number in My Mind "));

# while num > 5:
#     print('Not the right Number');
#     num = int(input("Enter A Number in My Mind "));


from re import L


userName = input("Enter User Name");
passWord = input("Enter Password");
credentials = "Invalid";

while credentials == "Invalid":   
    if userName=="Nikhil" and passWord == "Pass123":
        print("Login Successful");
        break;
    else:
        userName = input("Enter User Name");
        passWord = input("Enter Password");
        print("Invalid Credentials");


