techList = [".Net Core", "Angular", "Python","React", "SQL Server","Azure","DevOps"];

# print(techList[3]);

# for item in techList:
#     print(item);

# for item in "Nikhil Shah":
#     print(item);

# for item in techList:
#     if item == 'Python':
#         break;
#     else:
#         print(item);

# for a in range(0,10):
#     print(a);
    
# for a in range(1,50,5):
#     print(a);

for item in range(0,len(techList)):
    print(techList[item]);
    

    
    