# num1 = 20
# # num2 = 20
# # num3 = 20

# num2 =0;
# num3 = 0;
# num1 = num2 = num3

# num1,num2,num3 = 10,20,30

# # you can destroy the variable from memory at runtime
# del num2;

num1 = 10;
print(num1);
# del num1;
# print(num1);

num2 = 0;
num3 = 0;
num4 = 0;
num2 = num3 = num4 = num1;

print(num1);
print(num2);
print(num3);
print(num4);

n1 = n2 = n3 =n4 = n5 = n6 = 250;
print(n1);
print(n2);
print(n3);
print(n4);
print(n5);
print(n6);

del n3;









