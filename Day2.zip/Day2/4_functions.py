# def demoFunction():
#     print("This is line 1");
#     print("This is line 2");
#     print("This is line 3");
#     print("This is line 4");
#     print("This is line 5");
#     print("This is line 6");
#     print("This is line 7");
#     print("This is line 8");
#     print("This is line 9");
#     print("This is line 10");
#     print("------------------------------------------");
    



# demoFunction();
# demoFunction();
# demoFunction();


def Login():
    userName = input("Enter Your UserName");
    password = input("Enter the Password");
    if userName == "Nikhil" and password == "Pass!134":
        print("Welcome to the app");
    else:
        print("Invalid Credentials, please try again");


# code seperation, seperation of concerns - This are all wrapped as SOLID Principles
    