

# friends = ("Akshay","Jinesh","Mausam");
# print(friends);
# print(friends[1]);
# print(type(friends));
# name = 'Nikhil';
# age = 30;
# isPermenant = True;
# techList = ['Python',".Net","Angular"];
# print(type(name));
# print(type(age));
# print(type(isPermenant));
# print(type(techList));
# print(len(friends));

# newFriends = ("Mohit",False,10,"Kriti");
# print(newFriends);

# print(newFriends[1]);
# print(newFriends[1:3]);
# print(newFriends[-1]);
# print(newFriends[:2]);
# print(newFriends[3:]);

# techList = (".Net","Javascript","Angular","React");

# if "Java" in techList:
#     print("Eligible for Interview Call");
# else:
#     print("Not Eligible");


# temp_techList = [];
# #  create a new List
# temp_techList =list(techList);
# # assign the tuple to list 
# print(type(temp_techList));
# temp_techList.append("SQL Server");
# temp_techList.extend(["Azure","Data Science","ML","AI"]);
# print(temp_techList);

# techList = tuple(temp_techList);
# print(techList);



# list2 = ["AWS","GCP"];
# list2 = techList;

# print(type(list2));

from itertools import count


cars = ("Hyundai","Tata Motors","Maruti","Kia","Ford");

(Verna,Nexon,Brezza,*BMW) = cars;

print(type(BMW));

guest = ("Unwanted relative 1","Unwanted Neighbour 2", "Uninvited friend 3","Invited A","Wish B","Abc","fdsjhl","Invited A","sdfdsfretetr");

print(type(guest));
print(guest.count("Invited A"));


