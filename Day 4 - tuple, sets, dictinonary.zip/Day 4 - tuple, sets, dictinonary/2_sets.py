# cars = {"Verna","Tuson","Creata","Safari"};
# print(cars);


# Add a new value to set, using the add method
# cars.add("Elantra"); 
# print(cars);

# #remove the value frfom set
# cars.remove("Verna");
# print(cars);

# remove will give an error if value u passed does not exist
# cars.remove("Ford mustang");
# print(cars);

#instead use discard method, which will try to remove, will not throw error if value does not exist
# cars.discard("Ford Mustand");
# print(cars);


friend_1 = {"Verna","Ford","BMW"};
friend_2 = {"Verna","Ford","Merc","BMW","Ferrari"};

# Keep only matching and unique values between the 2 sets
friend_1.intersection_update(friend_2);
print(friend_1);

friend_1.symmetric_difference_update(friend_2);
result =friend_1;

print(result);

