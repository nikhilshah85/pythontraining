mySelf = {
    "name":"Nikhil",
    "city":"Mumbai",
    "designation":"Consultant",
    "email":"something@somewhere.com",
    "isPermenant":True,
    "call" :534920,
    "technologoies" : ["Python","AI","ML",".Net","Angular"]
}
# print(mySelf["email"]);
# print(mySelf["technologoies"][2]);

# print(mySelf.keys());

# print(mySelf.items());

# mySelf["email"] = "nikhilshah@hotmail.com";
# print(mySelf.items());

# if "lastname" in mySelf:
#     print("Dictionary is complete");
# else:
#     print("Incomplete");

# for x in mySelf:
#     print(x);

# for a,b in mySelf.items():
#     print(a + " : " + str(b));

# mySelf["height"] = 5.6;
# for a,b in mySelf.items():
#     print(a + " : " + str(b));

# mySelf["email"] ="hello@nowhere.com"
# for a,b in mySelf.items():
#     print(a + " : " + str(b));

mySelf.pop("email");
for a,b in mySelf.items():
    print(a + " : " + str(b));

# remove the dictionary from memory
del mySelf;
# del set



