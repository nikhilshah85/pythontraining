
# This is a Module 
import accounts as acc; 
import calculate as cal;


acc1 = acc.Accounts("Nikhil","Shah",30,6000);

print(acc1.Widraw(250));


acc2 = acc.Savings("Savings");

acc2.displayType();


print(cal.calculateEMI(25000,"Car"));

