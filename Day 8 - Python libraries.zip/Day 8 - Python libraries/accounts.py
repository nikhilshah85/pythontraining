class Accounts:
    def __init__(self,firstName,lastName,age,balance):
        self.accountName = firstName + " " + lastName;
        self.accountAge = age;
        self.accountBalance = balance;
        
        
    def Widraw(self,w_amount):
        self.accountBalance = self.accountBalance - w_amount;
        return self.accountBalance;
    
    
    def Deposit(self,d_amount):
        self.accountBalance = self.accountBalance + d_amount;
        return self.accountBalance;
    
class Savings(Accounts):
    def __init__(self,accType):
        self.accountType  = accType;
    
    def displayType(self):
        print("I am a Savings Account");
        
        
        
    
    