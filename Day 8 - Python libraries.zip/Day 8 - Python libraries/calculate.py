techList = ["Mictosoft","Google","IBM","Amazon"];

def displayListPosition():
    return techList[2];

def addNumbers(num1, num2):
    return num1 + num2;

def simpleIntrest(pricipal, roi,duration):
    return((pricipal * roi) / 100) * duration;

def calculateEMI(loanAmount,loanType):
    if loanType == "Home":
        return 5000;
    elif loanType == "Education":
        return 3000;
    elif loanType == "Car":
        return 8000;
    else:
        return 1000;
        
        
