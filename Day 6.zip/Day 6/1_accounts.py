class Accounts:
    # properties, like a private variable
    # accNo;
    # accName;
    # accBalance;
    # intrestRate;
    # transactionCharges;
        
    # when we crate a new account object, we want to collect 3 values from user
    #constructor
    def __init__(self,number, name, balance):
        self.accountNumber = number;
        self.accountName = name;
        self.accountBalance = balance;

# Parameter less Function
    def displayAccountDetails(self):
        print("Account Number " + str(self.accountNumber));
        print("Account Name : " + str(self.accountName));
        print("Account Balance " +str(self.accountBalance));
    
    def Widraw(self,w_amount):
        # perform validations, exceptions
        self.accountBalance = self.accountBalance - w_amount;
        return self.accountBalance;

    def Deposit(self, d_amount):
        self.accountBalance = self.accountBalance + d_amount;
        return self.accountBalance;


nikhilsAccount = Accounts(101,'Nikhil Shah',5000);
arunsAccount = Accounts(102,"Arun Sharma",8000);
kritisAccount = Accounts(103,"Kriti",18000);


allAccount = [nikhilsAccount,arunsAccount,kritisAccount];

for item in allAccount:
    item.displayAccountDetails();
    print('__________________');



    





            

    
    
