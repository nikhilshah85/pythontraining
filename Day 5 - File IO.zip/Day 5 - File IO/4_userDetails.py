print("Hello and welcome to APP - we store your Notes for centuries");
name = input("Enter Your Good Name : ")
print("Hello " + name);

print("Keep typing as much as you want and Press Enter twice to Rest");

newFile = open(name + ".txt",mode="w",encoding="utf-8");

details = input();
while details != "":
    newFile.write(details + "\n");    
    details = input();

print("Thank you, Your details are safe with us");
