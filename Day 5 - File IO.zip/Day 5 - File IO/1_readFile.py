myIntro = open("intro.txt",mode="r",encoding="utf-8");

info = myIntro.read(20);
print(info);
myIntro.close();