from lib2to3.pytree import convert


numberFile = open("lastnumber.txt",mode="r",encoding="utf-8");
number = int(numberFile.read());
number = number + 1;
numberFile.close();
saveNumber = open("lastnumber.txt",mode="w",encoding="utf-8");
saveNumber.write(str(number));
saveNumber.close();

def newGuestEntry():
    firstName = input("Enter First Name");
    lastName = input ("Enter Last Name");   
    email = input("Enter Email Address");
    mobile = str(input("Enter Mobile Number"));
    pan = input("Enter PAN Number");
    saveDetails = open(str(number) + ".txt",mode="w",encoding="utf-8");
    saveDetails.write("Guest ID " + str(number));
    saveDetails.write("Name : " + firstName + " " + lastName);
    saveDetails.write("Email Address : " + email);
    saveDetails.write("Mobile : " + mobile);
    saveDetails.write("PAN : " + pan);

    print("Guest Details Saved, Guest ID : " + str(number));
    saveDetails.close();

def viewGuestDetails(guestId):
    guest = open(guestId + ".txt",mode='r',encoding="utf-8");
    print(guest);
    guest.close();


print(" ~~~~~~~~~ Hello and Welcome to Guest mangegement System ~~~~~~~~~~");
print("1. New Guest");
print("2. Guest Details");
print("3. Guest List");
print("4. Exit");

continueApp = True;
while continueApp:
  option = int(input());
  if option == 1:
        newGuestEntry();
  elif option == 2:
      viewGuestDetails();
  elif option == 3:
      print("Feature coming soon");
  elif option == 4:
      print("Thank you, see you again");
      continueApp = False;
  else:
    print("Invalid Option selected");

    











