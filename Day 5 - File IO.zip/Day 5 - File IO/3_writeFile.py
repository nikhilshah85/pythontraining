from statistics import mode


details = open("newFile.txt",mode="w",encoding="utf-8");

details.write("Hello I am the first line \n");
details.write("Hello I am the second line \n");
details.write("Hello I am the Third line \n");
details.write("Hello I am the Fourth line \n");
details.write("Hello I am the Fifth line \n");

print("Contents written file");
details.close();