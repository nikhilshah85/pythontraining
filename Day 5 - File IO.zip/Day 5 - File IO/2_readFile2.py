details = open("C:\\Users\\Nikhilshah\\Desktop\\python fileIO\\test2.txt",mode="r",encoding="utf-8");

data = details.read();

print(data);

details.close();