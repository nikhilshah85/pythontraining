numberFile = open("lastnumber.txt",mode="r",encoding="utf-8");

number = int(numberFile.read());
number = number + 1;
print(number);

numberFile.close();

saveNumber = open("lastnumber.txt",mode="w",encoding="utf-8");
saveNumber.write(str(number));
saveNumber.close();